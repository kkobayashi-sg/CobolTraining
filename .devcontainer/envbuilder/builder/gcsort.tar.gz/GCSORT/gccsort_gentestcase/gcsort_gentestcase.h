/*
 *  Copyright (C) 2016 Sauro Menna
 *
 *	This file is part of gcsort_gentestcase.
 *
 *  GCSORT is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  GCSORT is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with GCSORT.  If not, see <http://www.gnu.org/licenses/>.

*/
#ifndef _GCSORT_GENTESTCASE_H_
#define _GCSORT_GENTESTCASE_H_
//#ifdef _WIN32

#include <stdio.h>	// for "FILE *" and "FILENAME_MAX"

#if defined(_MSC_VER) || defined(__MINGW32__) || defined(__MINGW64__)
	#include <windows.h>
#endif

#if	defined(_MSC_VER) || defined(__MINGW32__) || defined(__MINGW64__)
	#include <fcntl.h> 
	#include <windows.h>
	#include <io.h>
	#include <sys\types.h>
	#include <sys\stat.h>
#else
	#include <limits.h>
	#include <sys/io.h>
	#include <sys/stat.h>
	#include <time.h>
	#include <fcntl.h>
	#include <errno.h>
	#include <unistd.h>
#endif

#include <libcob.h>

#define   GEN_TYPE_ALL			0
#define   GEN_TYPE_CHARUPP		1
#define   GEN_TYPE_CHARLOW		2
#define   GEN_TYPE_CHARALL		3
#define   GEN_TYPE_NUMBER		4
#define   GEN_TYPE_SIGN			5

#define	  MAX_RECORD		32768
#define	  SIZEINT64				8
#define	  FIELD_TYPE_BINARY		1
#define	  FIELD_TYPE_FIXED		4

#define ALLOCATE_DATA	0
#define NOALLOCATE_DATA 1


#if	defined(__GNUC__) && !defined(__MINGW32__) && !defined(__MINGW64__)
	#if !defined(__MINGW32__) && !defined(__MINGW64__)
		typedef int HANDLE;
		#define INVALID_HANDLE_VALUE 0
		#define _S_IREAD	S_IREAD
		#define _S_IWRITE	S_IWRITE

		#define _O_TRUNC 	O_TRUNC
		#define _O_RDONLY	O_RDONLY
		#define _O_CREAT 	O_CREAT 
		#define _O_BINARY 	O_BINARY
		#define O_BINARY 	0
		#define _O_WRONLY   O_WRONLY

		#define _strtoll   strtoll
	#endif
#else
	#define _strtoll    _strtoi64

#endif



struct key_t {
	int		pos;
	int		len;
	int		iskey;
	int		seqkey;
	char    order[5];
	char	type[12];
	char	value[128];
};

struct params_t {
	char PgmCheckData[50];
	char PgmCheckSort[50];
	char ScriptName[50];
	char PathGen[FILENAME_MAX];
	char PathSrc[FILENAME_MAX];
	char PathTake[FILENAME_MAX];
	char PathBatsh[FILENAME_MAX];
	char Config[FILENAME_MAX];
	char szFileName[80];
	char szOrg[10];
	char szRec[10];
	int	 nLenMin, nLenMax;
	int  nMaxFields;
	unsigned long  nNumRec;
	int  byteorder;
	int  nNumKeys;
};


char gen_char ( int nT ) ;
int	read_fileCFG ( char* szCmdLine, struct params_t* params, struct key_t** pKey  );
int print_paramCFG (FILE* pFile, struct params_t* params, struct key_t** pKey );
int writeHeader (FILE* pFile, struct params_t* params, struct key_t** pKey );
int generate_file ( struct params_t* params, struct key_t** pKey );
int generate_Takefile ( struct params_t* params, struct key_t** pKey );
int destroy_paramCFG ( struct params_t* params, struct key_t** pKey );
void Usage ( void );
void CreateExampleFileConfig (void );
int Sort_Fields ( struct params_t* params, struct key_t** pKey );
int compare4qsort (const void *first, const void *second);
int check_param( struct params_t* params, struct key_t** pKey );
void write_line(FILE* pFile, char* pBuf);

cob_field* gen_cob_field_make (int type, int digits, int scale, int flags, int nLen, int nData);
void gen_setAttrib ( cob_field_attr *attrArea, int type, int nLen);
cob_field* gen_cob_field_create ( void );
void gen_cob_field_set (cob_field* field_ret, int type, int digits, int scale, int flags, int nLen);
void gen_cob_field_destroy ( cob_field* field_ret, int nData);
int gen_set_area (cob_file* file, unsigned char* szBuf, int nLen );
int genfile_SetInfoForFile( struct params_t* params, struct key_t** pKey, cob_file* stFileDef, int nMode);
void destroy_file (struct params_t* params, cob_file* stFile);
int gen_getFieldTypeLIBCOBFlags(const char *type);
void SetKeyForSort(struct params_t* params,  struct key_t** pKey, char* pBuf);

#endif //_GCSORT_GENTESTCASE_H_
