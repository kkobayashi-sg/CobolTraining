      *-------------------------------------------------------------------------------*
      * *********************************************
      * Author:    Sauro Menna
      * Date:      20160821
      * License
      *    Copyright 2016 Sauro Menna
      *    GNU Lesser General Public License, LGPL, 3.0 (or greater)
      * Purpose:   Sort COBOL module
      * Instruction use,sum fields
      * *********************************************
      * option:
      * cobc -x -t ..\listing\%1.lst -I ..\copy -Wall -fbinary-size=1--8
      *      -fnotrunc -fbinary-byteorder=big-endian -o ..\bin\%1 ..\src\%1.CBL
      * **********************************************************
      *-------------------------------------------------------------------------------*
       identification division.
       program-id. sbig001.
       environment division.
       configuration section.
       repository.
        function all intrinsic.
       input-output section.
       file-control.
      *sort input file
      * sinsqf01.cpy
           copy  sinsqf01.
      *sort output file
      * soutsqf01.cpy
           copy soutsqf01.
      *sort file (sd)
      * ssrtsqf01.cpy
           copy ssrtsqf01.
       data division.
       file section.
      * finsqf01.cpy
           copy finsqf01.
      * foutsqf01.cpy
           copy foutsqf01.
      * fsrtsqf01.cpy
           copy fsrtsqf01.
      *
       working-storage section.
       77 fs-infile                      pic xx.
       77 fs-outfile                     pic xx.
       77 fs-sort                        pic xx.
      *
           copy wktotsum01.
      *
      * ============================= *
      *01  save-record-sort              pic x(90).
      * ============================= *
      *77 record-counter-skip            USAGE BINARY-DOUBLE value zero.
       77 record-counter-in              USAGE BINARY-DOUBLE value zero.
       77 record-counter-out             USAGE BINARY-DOUBLE value zero.
       77 record-counter-disp            pic 9(11) value zero.
      *77 bIsFirstTime                   pic 9    value zero.
      *77 bIsPending                     pic 9    value zero.
      *01 current-time.
      *    05 ct-hours                   pic 99.
      *    05 ct-minutes                 pic 99.
      *    05 ct-seconds                 pic 99.
      *    05 ct-hundredths              pic 99.
      *
           copy wkenvfield.
      *
      * ============================= *
       procedure division.
      * ============================= *
       master-sort.
           move zero    to RETURN-CODE
           display "*===============================================* "
           display " Sort on ascending  key    srt-ch-field "
           display "*===============================================* "
      *
           copy prenvfield1.
      *
      *    perform 10 times
             sort file-sort
                on ascending  key    srt-ch-field
                                     srt-bi-field
                                     srt-fi-field
                                     srt-fl-field
                                     srt-pd-field
                                     srt-zd-field
                   with duplicates in  order
                    input procedure  is input-proc
                    output procedure is output-proc
      *    end-perform
           .

           display "*===============================================* "
           move record-counter-in    to record-counter-disp
           display " Record input  : "  record-counter-disp
           move record-counter-out   to record-counter-disp
           display " Record output : "  record-counter-disp
           display "*===============================================* "
           goback
           .
      *
           copy prenvfield2.
      *
      *
      * ============================= *
       input-proc.
      * ============================= *
           open input sortin.
           if fs-infile (1:1) not equal "0"
              exit paragraph
           end-if
           perform until exit
              read sortin
                at end exit perform
              end-read
              perform release-record
           end-perform
           close sortin
           .
      * ============================= *
       release-record.
      * ============================= *
           add 1 to record-counter-in
      ** filtering input record
           release sort-data from infile-record
           .
      *
      * ============================= *
       output-proc.
      * ============================= *
           open output sortout.
           if fs-sort (1:1) not equal "0"
              exit paragraph
           end-if
           perform until exit
             return file-sort at end
                display " "
                exit perform
             end-return
             perform verify-record-out
           end-perform.
      *    if (bIsPending = 1)
      *       perform write-record-out
      *    end-if
           close sortout.
      *
      * ============================= *
       verify-record-out.
      * ============================= *
      *
      * ## filtering data
      *
           write outfile-record from sort-data
           add 1 to record-counter-out
           .

      * ============================= *
      * add-totalizer.
      ** ============================= *
      ** Sum all Fields
      **  copy   prsrttot.cpy
      *     copy  praddsrttot.
      *     move 1            to bIsPending
      *    .
      * ============================= *
      * reset-totalizer.
      ** ============================= *
      **  copy   przerotot.cpy
      *     copy   przerotot.
      *     .
      * ============================= *
      * reset totals
      * ============================= *
      * write-record-out.
      ** ============================= *
      **    move low-value           to outfile-record
      *     add  1                   to record-counter-out
      **    move save-record-sort    to outfile-record
      **  copy   prtotout.cpy
      *     copy   prtotout.
      **    move zero                to bIsPending
      *     write outfile-record
      *     .
      * ============================= *
      * view-data.
      ** ============================= *
      *     read sortout at end
      *          display " "
      *     end-read
      *     if fs-outfile equal "00"
      *             display "============== ## ============== "
      *             display " sq="   out-seq-record
      *                     " ch="   out-ch-field
      *                     " bi="   out-bi-field
      *                     " fi="   out-fi-field
      *                     " pd="   out-pd-field
      *                     " zd="   out-zd-field
      *                     " fl="   out-fl-field
      *     end-if
      *     .
