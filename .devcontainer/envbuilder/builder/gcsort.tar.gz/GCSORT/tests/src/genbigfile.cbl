      *-------------------------------------------------------------------------------*
      * **********************************************************
      *  GCSORT Tests
      * **********************************************************
      * Author:    Sauro Menna
      * Date:      20160821
      * License
      *    Copyright 2016 Sauro Menna
      *    GNU Lesser General Public License, LGPL, 3.0 (or greater)
      * Purpose:   COBOL module generate file.
      *            Sort/Merge COBOL Program and GCSORT data file
      * **********************************************************
      * option:
      * cobc -x -t ..\listing\%1.lst -I ..\copy -Wall -fbinary-size=1--8
      *      -fnotrunc -fbinary-byteorder=big-endian -o ..\bin\%1 ..\src\%1.CBL
      * **********************************************************
      *-------------------------------------------------------------------------------*
       identification division.
       program-id. genbigfile.
       environment division.
       configuration section.
       repository.
        function all intrinsic.
        input-output section.
       file-control.
           copy sgensqf01.
       data division.
       file section.
           copy fgensqf01.
      *
       working-storage section.
      *01 RANDOM-NUMBER PIC 9999 value zero.
       77       record-counter-out    pic 9(11) value zero.
       77       program-name          pic x(12) value "*genbigfile*".
       77       ntimes                USAGE BINARY-LONG value 3.
       77       ntimes-disp           pic 9(9).
       77       fs-outfile            pic xx.
      *77       rrn                   pic 9(11)  value zero.
       01       idx                   USAGE BINARY-CHAR value zero.
       01       count-value           USAGE BINARY-DOUBLE value zero.
       78       tab-elements          value 26.
       01       tab-ch.
           02   tab-ele-num           pic 99    value tab-elements.
           02   tab-ele-value         pic x(52) value
      ******     "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA".
          "QQAAZZWWSSXXEEDDCCRRFFVVTTGGBBYYHHNNUUJJMMIIKKOOLLPP".
           02   tab-ch-ele redefines
                    tab-ele-value occurs tab-elements times pic xx.
       01    cmd-line           pic x(132).
      *
       77 env-pgm                       pic x(50).
       77 env-var-value                 pic x(28).
       01 env-num-rek.
          03 num-rek-9                  pic 9(9).
       procedure division.
       master-00.
      *
           display program-name " START"
      *  check if defined environment variables
           move 'dd_outfile'  to env-pgm
           perform check-env-var
      *
           open output outfile.
           if fs-outfile not = "00"
                display "outfile file status error : " fs-outfile
                move 25 to RETURN-CODE
                stop run
           end-if

      *  check if defined environment variables
           move 'numrek'  to env-pgm
           perform check-env-var
           move env-var-value(1:length of env-num-rek) to env-num-rek
           if  env-num-rek  is not numeric
                close outfile
                display ' env-var-value ' env-var-value
                display ' Num record not numeric ' env-num-rek
                display ' Num record num-rek-9   ' num-rek-9
                goback
           end-if

           display " Records to generate : " num-rek-9
           move num-rek-9 to  ntimes

           compute ntimes = ntimes / 2
           move ntimes to ntimes-disp

           display "   with crescent value   : " ntimes-disp
           move zero        to idx, count-value, seq-record
      *                         rrn
                             .

      *    compute RANDOM-NUMBER = 25 + (70 - 25 + 1) *
      *             (FUNCTION RANDOM)

           perform generate-file-asc ntimes times.

           move 27          to idx
           move -1          to count-value
           move ntimes      to seq-record
           add  1           to seq-record
      ***+++
           move ntimes to ntimes-disp
           display "   with decrescent value : " ntimes-disp
      **     display " Records to generate decrescent value : " ntimes-disp
           perform generate-file-des ntimes times.
           close outfile.
      *
           display "*===============================================* "
           display " Records created : "  record-counter-out
           display "*===============================================* "

           display program-name " END"
           goback
           .
      *
      *
      * ============================= *
        check-env-var.
      * ============================= *
      *
           accept env-var-value  from ENVIRONMENT env-pgm
      **
           if (env-var-value = SPACE)
             display "*===============================================*"
             display " Error - Environment variable " env-pgm
             display "         not found."
             display "*===============================================*"
             move 25 to RETURN-CODE
             goback
           end-if
           .
      *
       generate-file-asc.
           perform set-valuerecord-asc
           write outfile-record
           add 1 to record-counter-out
           .
       generate-file-des.
           perform set-valuerecord-des
           write outfile-record
           add 1 to record-counter-out
           .

       set-valuerecord-asc.
           move low-value      to ch-filler
      *    add 1 to rrn
           add 1 to seq-record
           add 1 to idx
           if idx > tab-ele-num
               move 1    to idx
           end-if

           move tab-ch-ele(idx) to  ch-field(1:2)
           move tab-ch-ele(idx) to  ch-field(3:3)
           perform add-counter
           move  count-value    to  bi-field
           perform add-counter
           move  count-value    to  fi-field
           perform add-counter
           move  count-value    to  fl-field
           perform add-counter
           move  count-value    to  pd-field
      *             display '[pos.] pd-field ' pd-field
           perform add-counter
           move  count-value    to  zd-field
           perform add-counter
           move  count-value    to  fl-field-1
           perform add-counter
           move  count-value    to  clo-field
           perform add-counter
           move  count-value    to  cst-field
           perform add-counter
           move  count-value    to  csl-field
           .

       add-counter.
           add  1            to count-value
      **-->>     add RANDOM-NUMBER to count-value
      *    if count-value > tab-elements
      *        move 1 to count-value
      *     end-if
           .

       set-valuerecord-des.
           move low-value      to ch-filler
      *    add 1 to rrn
           subtract 1 from seq-record
           subtract 1 from idx
           if idx <= zero
               move tab-elements to idx
           end-if
           move tab-ch-ele(idx) to  ch-field(1:2)
           move tab-ch-ele(idx) to  ch-field(3:3)
           perform sub-counter
           move  count-value    to  bi-field
           perform sub-counter
           move  count-value    to  fi-field
           perform sub-counter
           move  count-value    to  fl-field
           perform sub-counter
           move  count-value    to  pd-field
      **              display '[neg.] pd-field ' pd-field
           perform sub-counter
           move  count-value    to  zd-field
           perform sub-counter
           move  count-value    to  fl-field-1
           perform sub-counter
           move  count-value    to  clo-field
           perform sub-counter
           move  count-value    to  cst-field
           perform sub-counter
           move  count-value    to  csl-field
           .
       sub-counter.
           subtract 1 from count-value
      ***--->>>     subtract RANDOM-NUMBER from  count-value
                    giving   count-value
      **     if count-value <= zero
      **         move tab-elements to count-value
      **     end-if
           .
      Dview-data.
      D    read outfile at end
      D         Display "Outfile Input eof 2"
      D                end-read.
      D    if fs-outfile EQUAL "00"
      D            display "============== ## ============== "
      D            display " sq="   seq-record
      D                    " ch="    ch-field
      D                    " bi="    bi-field
      D                    " fi="    fi-field
      D                    " pd="    pd-field
      D                    " zd="    zd-field
      D                    " fl(2)=" fl-field
      D            display " clo="   clo-field
      D                    " cst="   cst-field
      D                    " csl="   csl-field
      D                    " fl(1)=" fl-field-1
      D    end-if
            .
